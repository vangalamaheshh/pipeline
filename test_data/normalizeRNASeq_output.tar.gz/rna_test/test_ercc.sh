#!/usr/bin/bash


R --no-save ./genes.fpkm_table ./output_ERCC/ WT_OE OE_0h_RNA_Seq,OE_36h_RNA_Seq,OE_96h_RNA_Seq,WT_0h_RNA_Seq,WT_36h_RNA_Seq,WT_96h_RNA_Seq TRUE < /ark/home/cl512/pipeline/normalizeRNASeq.R

